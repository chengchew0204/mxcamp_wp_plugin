<?php
/**
 * @package MxCamp_v3
 * @version 3.0
 */
/*
Plugin Name: MxCamp Slider V3
Plugin URI: https://nicochap.com
Description: Homepage Slider
Author: Nicolas Chapelain
Version: 3.0
Author URI: https://nicochap.com/
*/
/**
 * Add a hook for a shortcode tag
 */
function MxCamp_shortcodes_init_v3(){
    add_shortcode('mxcamp_get_posts_v3', 'mxcamp_get_posts_cb_v3');
}
add_action('init', 'MxCamp_shortcodes_init_v3');
/**
 * Register a shortcode
 *
 * @param array $atts Array of shortcode attributes
 */
function mxcamp_get_posts_cb_v3($atts) {
    // safeli extract custom arguments and set default values
    $atts = shortcode_atts(
        array(
            'post_type' => 'post',
        ), 
        $atts, 
        'mxcamp_get_posts_v3'
    );
    // define the array of query arguments
    $args = array(
        'cat' => 16,
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => 12,
        'orderby' => 'date',
        'order' => 'DESC'
    );
    $custom_posts = get_posts($args);
    $output = '';
	/**
	// Move MAPA as second item
	
	// Check if there are at least 2 items to avoid errors
	if (count($custom_posts) >= 2) {
		// Get the second item (index 1, since arrays are zero-indexed)
		$second_item = $custom_posts[1];

		// Remove the second item from its current position
		array_splice($custom_posts, 1, 1);

		// Insert the second item at the beginning (index 0)
		array_splice($custom_posts, 0, 0, [$second_item]);
	}**/

    if (!empty($custom_posts)) {
        $output .= '
        <link rel="stylesheet" type="text/css" href="/wp-content/plugins/mxcamp_V3/css/mxcamp_style-v3_0.css">
        <div class="slides" id="slides">
        <div id="loading-spinner-overlay" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: transparent; z-index: 10000; display: flex; align-items: center; justify-content: center; touch-action: none; pointer-events: auto; user-select: none; opacity: 1; transition: opacity 0.5s ease-out;">
            <div class="loading-spinner" style="width: 75px; height: 75px; border: 4.5px solid rgba(245, 245, 245, 0.3); border-top: 4.5px solid rgba(245, 245, 245, 0.9); border-radius: 50%; animation: spin 1s linear infinite;"></div>
        </div>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            #loading-spinner-overlay.fade-out {
                opacity: 0;
                pointer-events: none;
            }
        </style>
        ';

        $i = 0;
        $j = count($custom_posts);
        foreach ($custom_posts as $p) {
            $i++;
            setup_postdata($p);

            // 20251008: Reduce loading time by loading first a low resolution/pixelated image //
            // get featured image (thumbnail) ID and original URL
            $thumbnail_id = get_post_thumbnail_id($p->ID);
            $high_res_url = '';
            $low_res_url = '';

            if ($thumbnail_id) {
                $high_res_url = wp_get_attachment_image_url($thumbnail_id, 'full');

                // Build expected low-res filename (e.g. filename.webp)
                $info = pathinfo($high_res_url);
                $low_res_filename_partial = $info['filename'] . '-low-res';

                // Search for attachment by filename in the Media Library
                $args = array(
                    'post_type'      => 'attachment',
                    'posts_per_page' => 1,
                    'post_status'    => 'inherit',
                    'meta_query'     => array(
                        array(
                            'key'     => '_wp_attached_file',
                            'value'   => $low_res_filename_partial,
                            'compare' => 'LIKE',
                        )
                    )
                );

                $attachments = get_posts($args);

                if ( !empty($attachments) ) {
                    $low_res_url = wp_get_attachment_url( $attachments[0]->ID );
                } else {
                    // fallback to high-res if low-res not found
                    $low_res_url = $high_res_url;
                }
            }

            $slide_id = get_post_meta($p->ID, 'slide_id', true);
            $slide_title = get_post_meta($p->ID, 'slide_title', true);
            $title = $p->post_title;
			//$post_excerpt = 
            $id = $p->ID;
            $caret = ($i == $j) ? '' : '<div class="caretdiviphone"><a style="scroll-behavior:smooth"><img decoding="async" src="https://camp.mx/img/caret3.svg" style="width:60px; margin:20px"></a></div>';
            
            if ($i != 1) {
                $output .= '<div class="caretdiv"><a data-target-slide="' . esc_attr($slide_id) . '" style="scroll-behavior:smooth"><img src="https://camp.mx/img/caret3.svg" style="width:60px; margin:20px" /></a></div></div>';
            }

            // 20251008: Reduce loading time by loading first a low resolution/pixelated image //
            // Output slide (concatenation style)
            if ($high_res_url) {
                $output .= '
                <div class="slide_10 closed" 
                    id="' . esc_attr($slide_id) . '" 
                    data-title="' . esc_attr($title) . '" 
                    data-post="' . esc_attr($p->ID) . '" 
                    data-bg-low-res="' . esc_url($low_res_url) . '" 
                    data-bg-high-res="' . esc_url($high_res_url) . '" 
                    style="background-image:url(' . esc_url($low_res_url) . '); transition:background-image 0.4s ease, opacity 0.4s ease;">
                    
                    <img src="' . esc_url($high_res_url) . '" style="display:none" loading="lazy" decoding="async" alt="">
                    ' . $p->post_excerpt . '
                ';
            } else {
                // if there is no thumbnail, keep a minimal fallback
                $output .= '
                <div class="slide_10 closed no-thumbnail" 
                    id="' . esc_attr($slide_id) . '" 
                    data-title="' . esc_attr($title) . '" 
                    data-post="' . esc_attr($p->ID) . '">
                    ' . $p->post_excerpt . '
                ';
            }

            $output .= '
                    <div class="slide_10_bg"></div>
                    <div class="slide_10_scroll">
                        <svg class="ct-icon fakebutton" width="18" height="14" viewBox="0 0 18 14" aria-hidden="true" data-type="type-1"><rect y="0.00" width="18" height="1.7" rx="1"></rect><rect y="6.15" width="18" height="1.7" rx="1"></rect><rect y="12.3" width="18" height="1.7" rx="1"></rect></svg>
                        <div class="card ct-container">
                            <div class="card-header"><h2>' . $slide_title . '</h2></div>
                            <div class="card-content">
                                <div class="tap-top"></div>
                                <div class="tap-left"></div>
                                <div class="tap-right"></div>
                                ' . do_shortcode($p->post_content) . '
                                <div class="tap-bottom"></div>
                                <div class="hoverbackground" onclick="desHoverMe()" onmouseover="desHoverMe()"></div>
                            </div>
                        </div>
                    </div>
            ';
        }
        wp_reset_postdata(); // Reset the global $post variable to the current post in the main query.
        $output .= '
                </div>
            </div>
        <script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/image_swap.js"></script>
        <script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/navigation-v3_0.js"></script>
        <script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/slider_vimeo.js"></script>
		<script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/hovers.js"></script>
        <script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/assets.js"></script>
        <script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/BgVideoSound.js"></script>
        <!-- <script type="text/javascript" src="/wp-content/plugins/mxcamp_V3/add-onmouseover-detail.js"></script> -->
        <script src="https://player.vimeo.com/api/player.js"></script>
		<script>
			document.addEventListener(\'DOMContentLoaded\', () => {
			  const menu = document.getElementById(\'menu-main-menu-es-1\') || document.getElementById(\'menu-main-menu-en-1\');
			  if (menu) {
				const items = menu.querySelectorAll(\'li\');
				items.forEach(li => {
				  const child = li.firstElementChild;
				  if (child && (child.tagName === \'A\')) {
					// Create the outer div
					const outerDiv = document.createElement(\'div\');
					outerDiv.classList.add(\'hover\');
					child.classList.forEach(cls => outerDiv.classList.add(cls));
					const dataPost = child.getAttribute(\'data-post\');
					if (dataPost) {
					  outerDiv.setAttribute(\'data-post\', dataPost);
					}
					outerDiv.style.height = \'2.2em\';
					outerDiv.style.background = \'none\';
					outerDiv.style.padding = \'0px\';
					
					const url = child.getAttribute(\'href\');
					const linkEl = document.createElement(\'a\');
					linkEl.setAttribute(\'href\', url);
					linkEl.setAttribute(\'target\', "_blank");

                    // Create the image element
					const imageUrl = url.includes("senem") ? "https://camp.mx/wp-content/uploads/senem-1.jpg" : "https://camp.mx/wp-content/uploads/worldpackers.jpg";
                    const img = document.createElement(\'img\');
                    img.alt = ""; // Empty alt text as in your example
                    img.classList.add(\'wp-image-846\');
                    img.setAttribute(\'data-src\', url);
                    img.src = imageUrl;
					// img.addEventListener(\'click\', function() {e.preventDefault(); document.appendChild(linkEl); linkEl.click();});
					
					linkEl.appendChild(img);

					// Create the hover-content div
					const hoverContent = document.createElement(\'div\');
					hoverContent.classList.add(\'hover-content\');
					hoverContent.style.marginTop = \'40px\';
                    
                    // Append the image to hoverContent
                     hoverContent.appendChild(linkEl);
//  					const linkText = document.createElement(\'a\');
//  					linkText.setAttribute(\'href\', url);
//  					linkText.setAttribute(\'target\', "_blank");
//  					linkText.textContent = url.includes("senem") ? \'senem.mx\' : \'worldpackers.com\';
//  					linkText.style.setProperty(\'color\', \'black\', \'important\');
//  					linkText.style.setProperty(\'text-transform\', \'lowercase\');
//  					linkText.style.setProperty(\'text-align\', \'center\');
//  					hoverContent.appendChild(linkText);
					
					// Create plain text for menu
					const menuText = document.createElement(\'p\');
					menuText.classList.add(\'menu-item\');
					menuText.classList.add(\'menu-item-type-custom\');
					menuText.classList.add(\'menu-item-object-custom\');
					menuText.textContent = child.textContent;

					// Assemble the structure
					outerDiv.appendChild(hoverContent);
					outerDiv.appendChild(menuText);
					li.removeChild(child);
					li.appendChild(outerDiv);    // Adds outerDiv to the li
				  }
				});
				 const person1 = new Hovers(); 
			  }
			});
		</script>
        ';
        
    } else {
        $output = '<strong>Oops, pas de posts</strong>';
    }

    return $output;
}

/**
 * Inject close button and background click redirect on single event pages
 */
function mxcamp_inject_background_redirect() {
    if (is_singular('ajde_events')) {
        ?>
        <style type="text/css">
        /* Evo lightbox close buttons (circle with an "X") */
        .evo_lightboxes .evopopclose,
        .evo_lightboxes .evolbclose,
        .event-close-button {
          position: absolute;
          top: 20px;
          right: 20px;
          z-index: 90001;

          display: block;
          width: 28px;
          height: 28px;
          padding: 5px;
          margin: 0;

          background-color: #000;         /* button circle */
          border-radius: 50%;
          color: #666;                     /* irrelevant once text is hidden */
          text-indent: -9999px;            /* hide any text/icon font */

          cursor: pointer;
          box-sizing: content-box;
          font: 300 28px/1 var(--evo_font_2);
          border: none;
        }

        /* The "X" lines */
        .evo_lightboxes .evolbclose::before,
        .evo_lightboxes .evolbclose::after,
        .event-close-button::before,
        .event-close-button::after {
          content: "";
          position: absolute;
          left: 50%;
          top: 50%;
          width: 2px;
          height: 50%;
          background-color: #F5F5F5;       /* light cross; change to #666 if you want darker */
          transform-origin: center;
        }

        .evo_lightboxes .evolbclose::before,
        .event-close-button::before {
          transform: translate(-50%, -50%) rotate(45deg);
        }

        .evo_lightboxes .evolbclose::after,
        .event-close-button::after {
          transform: translate(-50%, -50%) rotate(-45deg);
        }
        
        /* Position close button on single event pages */
        body.single-ajde_events .event-close-button,
        body.single-ajde_events .event-close-button.evolbclose {
            position: absolute !important;
            top: 10px !important;
            right: 10px !important;
            z-index: 90001 !important;
            left: auto !important;
            bottom: auto !important;
        }
        
        /* Ensure the event container has relative positioning */
        body.single-ajde_events .eventon_main_section,
        body.single-ajde_events .ajde_evcal_calendar.eventon_single_event,
        body.single-ajde_events .eventon_single_event {
            position: relative !important;
        }
        
        /* Video styles for single event pages */
        body.single-ajde_events .fullscreen img.playbut {
            left: -13px;
            bottom: -7px;
            width: 100px;
            cursor: pointer;
            transform-origin: left bottom;
            transform: scale(1.1);
        }
        
        @media screen and (max-width:600px) {
            body.single-ajde_events .fullscreen img.playbut {
                left: 0;
                bottom: 0;
                width: 50px;
            }
        }
        
        body.single-ajde_events .videoplaying .playbut {
            display: none;
        }
        
        body.single-ajde_events .fullscreen .pausebut {
            position: absolute;
            left: 5px;
            bottom: 5px;
            width: 30px;
            cursor: pointer;
            display: none;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 50%;
            padding: 7px;
        }
        
        body.single-ajde_events .videoplaying.fullscreen:hover .pausebut {
            display: block;
        }
        
        body.single-ajde_events .evocard_row .fullscreen .timevideo {
            margin-top: 5px !important;
            position: absolute !important;
            bottom: 0 !important;
            top: unset !important;
            right: 0 !important;
            font-size: 15px !important;
            z-index: 10 !important;
            display: none;
        }
        
        body.single-ajde_events .fullscreen .timevideo {
            color: #F5f5f5 !important;
        }
        
        body.single-ajde_events .videoplaying:hover .timevideo {
            display: block;
        }
        
        body.single-ajde_events .ajde_evcal_calendar.boxy .eventon_list_event.event {
            aspect-ratio: 3/4 !important;
            width: auto !important;
            min-height: unset !important;
            background-repeat: no-repeat;
        }
        
        body.single-ajde_events .evo_metarow_directimg.evcal_evdata_row {
            padding: 0 !important;
            height: auto;
        }
        
        body.single-ajde_events .desc_trig_outter {
            background-repeat: no-repeat;
            background-size: cover !important;
            background-position-x: center;
        }
        
        body.single-ajde_events .evcal_evdata_img, 
        body.single-ajde_events .ftimage {
            aspect-ratio: auto !important;
        }
        
        body.single-ajde_events div.fullscreen {
            aspect-ratio: auto !important;
            height: 100%;
        }
        
        body.single-ajde_events .fullscreen video {
            height: auto !important;
            left: 0;
            object-fit: cover;
            top: 0;
            position: relative;
            transform: none;
            transition: none;
            width: 100%;
            z-index: 0;
        }
        
        /* Hide repeating event tags on single event pages */
        body.single-ajde_events .evoet_tags.evo_above_title .evo_event_headers.repeating,
        body.single-ajde_events .evo_event_headers.repeating {
            display: none !important;
        }
        
        /* Video loader spinner for single event pages */
        body.single-ajde_events .card-video-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 5;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        /* Make videos clearly clickable for play/pause */
        body.single-ajde_events .fullscreen video {
            cursor: pointer;
        }
        
        body.single-ajde_events .fullscreen {
            cursor: pointer;
        }
        
        /* Don't show pointer cursor when native controls are active */
        body.single-ajde_events .fullscreen video[controls] {
            cursor: default;
        }
        
        @media screen and (max-width: 600px) {
            body.single-ajde_events .event-close-button,
            body.single-ajde_events .event-close-button.evolbclose {
                top: 5px !important;
                right: 5px !important;
                width: 32px !important;
                height: 32px !important;
            }
        }
        </style>
        <script type="text/javascript">
        (function() {
            'use strict';
            
            function initBackgroundRedirect() {
                console.log('Initializing single event background redirect...');
                
                // Add close button to single event pages
                function addCloseButton() {
                    // Check if close button already exists
                    if (document.querySelector('.event-close-button')) {
                        console.log('Close button already exists, skipping');
                        return;
                    }
                    
                    // Check if we're on a single event page
                    const isSingleEventPage = document.body.classList.contains('single-ajde_events') ||
                                            document.querySelector('.ajde_evcal_calendar.eventon_single_event') ||
                                            document.querySelector('.eventon_single_event') ||
                                            document.querySelector('.evo_sin_page');
                    
                    if (!isSingleEventPage) {
                        console.log('Not a single event page, skipping close button');
                        return;
                    }
                    
                    console.log('Adding close button to single event page');
                    
                    // Find the best container for the close button
                    const eventContainer = document.querySelector('.eventon_main_section') || 
                                         document.querySelector('.ajde_evcal_calendar.eventon_single_event') ||
                                         document.querySelector('.eventon_single_event') ||
                                         document.querySelector('.evo_sin_page');
                    
                    if (!eventContainer) {
                        console.log('No suitable event container found for close button positioning');
                        return;
                    }
                    
                    const closeButton = document.createElement('button');
                    closeButton.className = 'event-close-button evolbclose';
                    closeButton.setAttribute('aria-label', 'Close event');
                    closeButton.textContent = 'Close'; // Hidden by CSS text-indent
                    
                    // Add close button click handler
                    closeButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        
                        // Detect language and redirect to appropriate calendar
                        const isEnglish = document.documentElement.lang.includes('en') || 
                                        window.location.href.includes('/en/') ||
                                        document.querySelector('#menu-main-menu-en') ||
                                        document.querySelector('#menu-main-menu-en-1');
                        const redirectUrl = isEnglish ? 'https://camp.mx/calendar' : 'https://camp.mx/calendario';
                        
                        console.log('Close button clicked, redirecting to:', redirectUrl);
                        
                        // Add transition effect
                        document.body.style.transition = 'opacity 0.2s ease';
                        document.body.style.opacity = '0.9';
                        
                        setTimeout(function() {
                            window.location.href = redirectUrl;
                        }, 150);
                    });
                    
                    // Append close button to the event container for relative positioning
                    eventContainer.appendChild(closeButton);
                    console.log('Close button successfully added to event container:', eventContainer.className);
                }
                
                // Add close button immediately and also after delays to ensure it loads
                addCloseButton();
                setTimeout(addCloseButton, 100);
                setTimeout(addCloseButton, 500);
                setTimeout(addCloseButton, 1000);
                setTimeout(addCloseButton, 2000);
                
                // Also try when DOM content loads
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', addCloseButton);
                }
                
                // And when window loads
                window.addEventListener('load', addCloseButton);
                
                // Detect language from multiple sources
                let languagePage = document.documentElement.lang;
                
                if (!languagePage || languagePage === '') {
                    if (window.location.href.includes('/en/')) {
                        languagePage = 'en-US';
                    } else if (document.querySelector('a[href*="/en/#"]')) {
                        languagePage = 'en-US';
                    } else if (document.querySelector('#menu-main-menu-en')) {
                        languagePage = 'en-US';
                    } else {
                        languagePage = 'es-ES';
                    }
                }
                
                const isEnglish = languagePage.includes('en');
                const redirectUrl = isEnglish ? 'https://camp.mx/calendar' : 'https://camp.mx/calendario';
                const eventsUrl = isEnglish ? 'https://camp.mx/events' : 'https://camp.mx/eventos';
                
                console.log('Language detected:', languagePage);
                console.log('Redirect URL will be:', redirectUrl);
                console.log('Events URL will be:', eventsUrl);
                console.log('Starting burger menu override process...');
                
                // Override burger menu behavior on single event pages
                function overrideBurgerMenu() {
                    console.log('overrideBurgerMenu function called...');
                    const burgerMenu = document.querySelector('button.ct-header-trigger.ct-toggle');
                    console.log('Burger menu element found:', burgerMenu);
                    if (burgerMenu) {
                        console.log('Found burger menu, overriding behavior...');
                        
                        // Remove data-toggle-panel attribute to prevent default panel behavior
                        burgerMenu.removeAttribute('data-toggle-panel');
                        burgerMenu.removeAttribute('aria-expanded');
                        
                        // Remove any existing click event listeners by cloning the element
                        const newBurgerMenu = burgerMenu.cloneNode(true);
                        newBurgerMenu.removeAttribute('data-toggle-panel');
                        newBurgerMenu.removeAttribute('aria-expanded');
                        burgerMenu.parentNode.replaceChild(newBurgerMenu, burgerMenu);
                        
                        // Add new click event that redirects to events page
                        newBurgerMenu.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            console.log('Burger menu clicked on single event page, redirecting to:', eventsUrl);
                            
                            // Close the panel if it's open
                            const offcanvas = document.getElementById('offcanvas');
                            if (offcanvas) {
                                offcanvas.classList.remove('active');
                            }
                            
                            // Add transition effect
                            document.body.style.transition = 'opacity 0.2s ease';
                            document.body.style.opacity = '0.9';
                            
                            setTimeout(function() {
                                window.location.href = eventsUrl;
                            }, 150);
                        });
                        
                        console.log('Burger menu behavior overridden for single event page');
                        
                        // Also override any future script attempts to modify the burger menu
                        setTimeout(function() {
                            const checkBurger = document.querySelector('button.ct-header-trigger.ct-toggle');
                            if (checkBurger && checkBurger !== newBurgerMenu) {
                                console.log('Burger menu was replaced by another script, re-overriding...');
                                overrideBurgerMenu();
                            }
                        }, 2000);
                        
                    } else {
                        console.log('Burger menu not found, retrying in 500ms...');
                        setTimeout(overrideBurgerMenu, 500);
                    }
                }
                
                // Call the override function multiple times to ensure it works
                overrideBurgerMenu();
                setTimeout(overrideBurgerMenu, 1000);
                setTimeout(overrideBurgerMenu, 3000);
                
                // Backup approach - direct document click listener for burger menu
                document.addEventListener('click', function(e) {
                    const burgerButton = e.target.closest('button.ct-header-trigger.ct-toggle');
                    if (burgerButton) {
                        console.log('Direct burger menu click intercepted!');
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        
                        // Close the panel if it's open
                        const offcanvas = document.getElementById('offcanvas');
                        if (offcanvas) {
                            offcanvas.classList.remove('active');
                        }
                        
                        console.log('Redirecting to events page from direct listener:', eventsUrl);
                        
                        // Add transition effect
                        document.body.style.transition = 'opacity 0.2s ease';
                        document.body.style.opacity = '0.9';
                        
                        setTimeout(function() {
                            window.location.href = eventsUrl;
                        }, 150);
                    }
                }, true); // Use capture phase to intercept early
                
                document.body.addEventListener('click', function(event) {
                    // Check if this is a burger menu click first
                    if (event.target.closest('button.ct-header-trigger.ct-toggle') || 
                        event.target.closest('.ct-header-trigger')) {
                        console.log('Burger menu click detected, letting it handle the redirect');
                        return;
                    }
                    
                    if (event.target.tagName === 'A' || 
                        event.target.tagName === 'BUTTON' || 
                        event.target.tagName === 'INPUT' || 
                        event.target.tagName === 'TEXTAREA' || 
                        event.target.tagName === 'SELECT' ||
                        event.target.tagName === 'VIDEO' ||
                        event.target.tagName === 'IMG' ||
                        event.target.closest('a') ||
                        event.target.closest('button') ||
                        event.target.closest('form') ||
                        event.target.closest('video') ||
                        event.target.closest('.video-events-grid') ||
                        event.target.closest('.fullscreen.video') ||
                        event.target.closest('nav') ||
                        event.target.closest('header') ||
                        event.target.closest('footer') ||
                        event.target.closest('#offcanvas') ||
                        event.target.closest('.ct-panel') ||
                        event.target.closest('.evolbclose') ||
                        event.target.closest('.event-close-button') ||
                        event.target.closest('.ct-social-box') ||
                        event.target.closest('.evcal_evdata_row') ||
                        event.target.closest('.comment-form') ||
                        event.target.closest('.cta') ||
                        event.target.closest('.playbut') ||
                        event.target.closest('.pausebut')) {
                        console.log('Click on interactive element, not redirecting');
                        return;
                    }
                    
                    const main = document.getElementById('main');
                    const mainContainer = document.getElementById('main-container');
                    
                    if ((main && main.contains(event.target)) || 
                        (mainContainer && mainContainer.contains(event.target))) {
                        
                        console.log('Background clicked, redirecting to:', redirectUrl);
                        
                        document.body.style.transition = 'opacity 0.2s ease';
                        document.body.style.opacity = '0.9';
                        
                        setTimeout(function() {
                            window.location.href = redirectUrl;
                        }, 150);
                    }
                });
                
                const style = document.createElement('style');
                style.textContent = `
                    body.single-ajde_events {
                        cursor: pointer;
                    }
                    body.single-ajde_events button{
                        cursor: pointer !important;
                    }
                    
                    body.single-ajde_events .video-events-grid,
                    body.single-ajde_events .fullscreen,
                    body.single-ajde_events .playbut,
                    body.single-ajde_events .pausebut {
                        cursor: pointer !important;
                    }
                    
                    /* Links should ALWAYS show pointer cursor with highest specificity */
                    body.single-ajde_events a,
                    body.single-ajde_events .eventon_full_description a,
                    body.single-ajde_events .eventon_desc_in a,
                    body.single-ajde_events .evcal_evdata_cell a,
                    body.single-ajde_events .evocard_box a,
                    body.single-ajde_events p a,
                    body.single-ajde_events center a,
                    body.single-ajde_events font a {
                        cursor: pointer !important;
                    }
                    body.single-ajde_events .eventon_full_description,
                    body.single-ajde_events .evcal_evdata_row,
                    body.single-ajde_events .evocard_box,
                    body.single-ajde_events .event_excerpt,
                    body.single-ajde_events .eventon_desc_in,
                    body.single-ajde_events .evo_metarow_details,
                    body.single-ajde_events .evcal_evdata_cell,
                    body.single-ajde_events h3,
                    body.single-ajde_events mark,
                    body.single-ajde_events hr,
                    body.single-ajde_events input,
                    body.single-ajde_events textarea,
                    body.single-ajde_events select,
                    body.single-ajde_events video,
                    body.single-ajde_events nav,
                    body.single-ajde_events header,
                    body.single-ajde_events footer,
                    body.single-ajde_events .cta,
                    body.single-ajde_events .fullscreen.video,
                    body.single-ajde_events .comment-form {
                        cursor: default !important;
                    }
                `;
                document.head.appendChild(style);
                
                console.log('Background redirect initialized successfully');
            }
            
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initBackgroundRedirect);
            } else {
                initBackgroundRedirect();
            }
            
            setTimeout(initBackgroundRedirect, 1000);
            
        })();
        </script>
        
        <script type="text/javascript">
        // Video handling for single event pages
        (function() {
            'use strict';
            
            function initSingleEventVideo() {
                // Only run on single event pages
                if (!document.body.classList.contains('single-ajde_events')) {
                    return;
                }
                
                console.log('Initializing video for single event page...');
                
                // Look for video elements on single event pages
                const thisvideo = document.querySelector('body.single-ajde_events .eventon_full_description video.video-events-grid');
                
                if (!thisvideo) {
                    console.log('No video found on single event page');
                    return;
                }
                
                console.log('Video element found on single event page:', thisvideo);
                
                // Find the header container - different selector for single event pages
                const thisHeader = document.querySelector('body.single-ajde_events .evocard_box.ftimage > div');
                
                if (!thisHeader) {
                    console.log('No header container found for video placement');
                    return;
                }
                
                // Old spinner removed - using new spinner system in setupNormalEventBehaviorSingle
                
                // Remove default controls
                thisvideo.removeAttribute("controls");
                
                // Safari/iOS autoplay compatibility setup
                thisvideo.setAttribute('playsinline', '');
                thisvideo.preload = thisvideo.preload || 'metadata';
                thisvideo.muted = true; // Required for autoplay on Safari/iOS
                thisvideo.volume = 0.5; // Will be applied when unmuted
                
                // Create fullscreen container
                const fullScreenDiv = document.createElement('div');
                fullScreenDiv.classList.add('fullscreen');
                
                // Move video to fullscreen container
                fullScreenDiv.appendChild(thisvideo);
                
                // Setup normal event behavior - show featured image, hide video until ready
                // This function now handles the spinner creation and positioning
                setupNormalEventBehaviorSingle(thisvideo, thisHeader, fullScreenDiv);
                
                // Trigger video loading without autoplay - just load the video
                setTimeout(() => {
                    thisvideo.load(); // Reload the video to trigger loading events
                    console.log('Video load triggered');
                }, 100);
                
                var controlsVisible = false;
                thisvideo.addEventListener('timeupdate', function () {
                    if (thisvideo.currentTime >= 0.5 && !controlsVisible) {
                        controlsVisible = true;
                    }
                });
                
                // Add to header
                thisHeader.appendChild(fullScreenDiv);
                
                // Play/pause buttons removed for event videos - videos are click-to-play without buttons
                
                function playVideo() {
                    const divplaying = document.querySelectorAll('.videoplaying');
                    // Stop other playing videos
                    divplaying.forEach(div => {
                        div.classList.remove('videoplaying');
                    });
                    
                    // Unmute on user gesture (enables audio on Safari/iOS)
                    thisvideo.muted = false;
                    thisvideo.play().catch(error => {
                        console.log('Play failed:', error.message);
                    });
                    thisvideo.closest(".fullscreen").classList.add('videoplaying');
                }
                
                function pauseVideo() {
                    thisvideo.pause();
                    const divplaying = document.querySelectorAll('.videoplaying');
                    divplaying.forEach(div => {
                        div.classList.remove('videoplaying');
                    });
                }
                
                // Play/pause button event listeners removed - videos are now click-to-play without buttons
                
                // Create time display
                const timeDisplay = document.createElement('p');
                timeDisplay.classList.add('timevideo');
                
                fullScreenDiv.appendChild(timeDisplay);
                // Play/pause buttons removed - videos are click-to-play without buttons
                
                // Add click-to-pause/play functionality to the video element
                thisvideo.addEventListener('click', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    
                    // Don't interfere if native controls are visible (long videos)
                    if (thisvideo.controls && thisvideo.duration > 120) {
                        console.log('Native controls active, letting default video click behavior handle it');
                        return;
                    }
                    
                    if (thisvideo.paused) {
                        console.log('Video clicked - playing');
                        playVideo();
                    } else {
                        console.log('Video clicked - pausing');
                        pauseVideo();
                    }
                });
                
                // Also make the fullscreen container clickable (but not the time display)
                fullScreenDiv.addEventListener('click', function(event) {
                    // Don't trigger if clicking on time display
                    if (event.target === timeDisplay) {
                        return;
                    }
                    
                    // Don't interfere if native controls are visible (long videos)
                    if (thisvideo.controls && thisvideo.duration > 120) {
                        return;
                    }
                    
                    event.preventDefault();
                    event.stopPropagation();
                    
                    if (thisvideo.paused) {
                        console.log('Video container clicked - playing');
                        playVideo();
                    } else {
                        console.log('Video container clicked - pausing');
                        pauseVideo();
                    }
                });
                
                // Display total duration when video metadata is loaded
                thisvideo.addEventListener('loadedmetadata', function() {
                    const durationMinutes = Math.floor(thisvideo.duration / 60);
                    const durationSeconds = Math.floor(thisvideo.duration % 60);
                    
                    timeDisplay.textContent = durationMinutes + ':' + durationSeconds.toString().padStart(2, '0');
                    console.log("Video duration:" + thisvideo.duration);
                    
                    // Add video controls for large videos
                    if (thisvideo.duration > 120) { // min duration to activate controls
                        thisvideo.controls = "controls";
                        controlsVisible = true;
                        // Hide our time display for long videos with native controls
                        const timeEl = document.querySelector('body.single-ajde_events .timevideo');
                        if (timeEl) timeEl.style.display = 'none';
                        console.log("Activating Video controls for long video on single event page");
                        
                        // No autoplay for single event pages - user must click play even for long videos
                    }
                });
                
                // Update progress bar and remaining time
                thisvideo.addEventListener('timeupdate', function () {
                    const elapsedTime = thisvideo.currentTime;
                    const totalTime = thisvideo.duration;
                    
                    // Calculate remaining time
                    const remainingTime = totalTime - elapsedTime;
                    const remainingMinutes = Math.floor(remainingTime / 60);
                    const remainingSeconds = Math.floor(remainingTime % 60);
                    
                    // Display remaining time
                    timeDisplay.textContent = remainingMinutes + ':' + remainingSeconds.toString().padStart(2, '0');
                });
                
                console.log('Single event video setup completed');
            }
            
            /**
             * Sets up normal event behavior for video events on single pages
             * @param {HTMLVideoElement} videoEl - The video element
             * @param {HTMLElement} headerEl - The header container element
             * @param {HTMLElement} containerEl - The fullscreen container element
             */
            function setupNormalEventBehaviorSingle(videoEl, headerEl, containerEl) {
                // Find the original header image
                const headerImg = headerEl.querySelector('img');
                if (!headerImg) {
                    console.log('No header image found, video will show immediately');
                    return;
                }
                
                // Keep the original header image visible (like normal events)
                headerImg.style.display = 'block';
                console.log('Keeping featured image visible like normal events');
                
                // Hide the video initially
                videoEl.style.display = 'none';
                console.log('Video hidden initially - will show when ready');
                
                // Set video poster for when it becomes visible
                const posterUrl = headerImg.currentSrc || headerImg.src;
                if (posterUrl && !videoEl.poster) {
                    videoEl.poster = posterUrl;
                }
                
        // Create and show loading spinner above the feature image
        const loadingSpinner = document.createElement('div');
        loadingSpinner.className = 'video-loading-spinner-overlay';
        loadingSpinner.innerHTML = `
            <div class="video-loading-spinner">
                <div class="spinner"></div>
            </div>
        `;
        
        // Position spinner in the header container (will be over the feature image)
        // The containerEl (fullscreen div) will be appended to headerEl later
        headerEl.style.position = 'relative';
        headerEl.appendChild(loadingSpinner);
        console.log('Loading spinner added to header container above feature image');
                
                // Show video and hide image + spinner when video is ready to play
                const showVideo = () => {
                    headerImg.style.display = 'none';
                    videoEl.style.display = 'block';
                    // Hide the loading spinner
                    if (loadingSpinner) {
                        loadingSpinner.style.display = 'none';
                        console.log('Loading spinner hidden');
                    }
                    // Keep video muted initially - will unmute when user clicks play
                    console.log('Video ready - hiding featured image and spinner, showing video (paused)');
                };
                
                // Listen for video ready events - add debugging to see which events fire
                const events = ['loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough'];
                const cleanup = () => {
                    events.forEach(event => videoEl.removeEventListener(event, handleReady));
                };
                
                const handleReady = (event) => {
                    console.log('Video ready event fired:', event.type, 'readyState:', videoEl.readyState);
                    showVideo();
                    cleanup();
                };
                
                // Add debugging for all events
                events.forEach(event => {
                    videoEl.addEventListener(event, (e) => {
                        console.log('Video event:', e.type, 'readyState:', videoEl.readyState);
                    });
                });
                
                events.forEach(event => videoEl.addEventListener(event, handleReady, { once: true }));
                
                // On error, hide spinner and keep the featured image visible (like normal events)
                videoEl.addEventListener('error', () => {
                    headerImg.style.display = 'block';
                    videoEl.style.display = 'none';
                    if (loadingSpinner) {
                        loadingSpinner.style.display = 'none';
                        console.log('Video error - hiding loading spinner, keeping featured image visible');
                    }
                    cleanup();
                    console.log('Video error - keeping featured image visible like normal event');
                }, { once: true });
                
                videoEl.addEventListener('stalled', () => {
                    if (loadingSpinner) {
                        loadingSpinner.style.display = 'none';
                        console.log('Video stalled - hiding loading spinner');
                    }
                    cleanup();
                }, { once: true });
            }
            
            // Initialize video handling
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initSingleEventVideo);
            } else {
                initSingleEventVideo();
            }
            
            // Also try after delays to ensure it loads
            setTimeout(initSingleEventVideo, 500);
            setTimeout(initSingleEventVideo, 1000);
            setTimeout(initSingleEventVideo, 2000);
            
        })();
        </script>
        <?php
    }
}
add_action('wp_footer', 'mxcamp_inject_background_redirect');

/**
 * Inject hash-based URL redirects for events/eventos to calendar pages
 */
function mxcamp_inject_hash_redirects() {
    ?>
    <script type="text/javascript">
    (function() {
        'use strict';
        
        function checkHashRedirects() {
            const urlHash = window.location.hash;
            const currentPath = window.location.pathname;
            
            if (urlHash) {
                const cleanHash = urlHash.substring(1);
                
                // Redirect #events to calendar (English)
                if (cleanHash === 'events' && (currentPath.includes('/en') || document.documentElement.lang === 'en-US')) {
                    console.log('Redirecting #events to calendar');
                    window.location.href = 'https://camp.mx/calendar';
                    return;
                }
                
                // Redirect #eventos to calendario (Spanish)
                if (cleanHash === 'eventos' && (!currentPath.includes('/en') || document.documentElement.lang === 'es-ES')) {
                    console.log('Redirecting #eventos to calendario');
                    window.location.href = 'https://camp.mx/calendario';
                    return;
                }
            }
        }
        
        // Run immediately if DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', checkHashRedirects);
        } else {
            checkHashRedirects();
        }
        
        // Also check on hash change events
        window.addEventListener('hashchange', checkHashRedirects);
        
    })();
    </script>
    <?php
}
add_action('wp_footer', 'mxcamp_inject_hash_redirects');


?>